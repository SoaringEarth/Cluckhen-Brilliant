//
//  Cluckhen_BrilliantTests.m
//  Cluckhen BrilliantTests
//
//  Created by Jonathon Albert on 07/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Cluckhen_BrilliantTests.h"

@implementation Cluckhen_BrilliantTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Cluckhen BrilliantTests");
}

@end
