//
//  Cluckhen_BrilliantTests.h
//  Cluckhen BrilliantTests
//
//  Created by Jonathon Albert on 07/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Cluckhen_BrilliantTests : SenTestCase

@end
